#pragma once
#include "main.h"

void addNewStudent(SinhVien sv[],int id, int numberStudent);
void showStudent(SinhVien sv[], int numberStudent);
int removeStudent(SinhVien sv[], int numberStudent);
void modifyStudent(SinhVien sv[], int numberStudent);
